from pypresence import Presence
from time import time
 
RPC = Presence("1219596004224143430")
btns = [
    {
        "label": "GitHub",
        "url": "https://github.com/FarguDev"
    },
    {
        "label": "VK",
        "url": "https://vk.com/limitflow"
    }
]
 
RPC.connect()
RPC.update(
    state="Тыковка!",
    details="Арбузик!",
    start=time(),
    buttons=btns,
    large_image="python",
    small_image="python",
    large_text="I love python",
    small_text="Love!"
)
 
input() # Чтобы программа резко не закрывалась.